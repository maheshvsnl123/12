
#include "../board_definition.h"

RccSysClockConfig maxSysClockCfg;
BoardLED boardLEDs[0];
BoardButton boardButtons[0];

uint8_t boardLEDs_count = 0;
uint8_t boardButtons_count = 0;
